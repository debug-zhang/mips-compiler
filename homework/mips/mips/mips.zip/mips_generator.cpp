﻿#include "mips_generator.h"

MipsGenerator::MipsGenerator(string inputFileName, string outputFileName,
	StringTable* stringTable, map<string, SymbolTable*> symbolTableMap) {
	this->midcode.open(inputFileName);
	this->objCode = new ObjCode(outputFileName);
	this->checkTable = new CheckTable();
	this->stringTable = stringTable;
	this->symbolTableMap = symbolTableMap;
	this->newReg = 0;
	this->dmOffset = 0;
}

vector<string> MipsGenerator::Split(string s, char delimiter) {
	vector<string> tokens;
	string token;
	istringstream tokenStream(s);
	while (getline(tokenStream, token, delimiter)) {
		tokens.push_back(token);
	}
	return tokens;
}

void MipsGenerator::InitDataSeg() {
	objCode->Output(Instr::data);
	objCode->Output(Instr::data_identifier, "global", 240);
	for (int i = 0; i < stringTable->GetStringCount(); i++) {
		string data_string = "str_" + to_string(i) + ": .asciiz \"" + stringTable->GetString(i) + "\"";
		objCode->Output(Instr::data_string, data_string);
	}
	objCode->Output(Instr::data_align, 4);
}

void MipsGenerator::InitStack() {
	objCode->Output(Instr::move, Reg::gp, Reg::sp);
	objCode->Output(Instr::move, Reg::fp, Reg::sp);
}

void MipsGenerator::LoadTable(int level, string tableName) {
	this->checkTable->SetTable(level, symbolTableMap.at(tableName));
}

void MipsGenerator::InitVariable(int level) {
	int count = 0;
	int offset = 0;

	map<string, Symbol*> symbolMap = checkTable->GetSymbolMap(level);
	map<string, Symbol*>::iterator iter = symbolMap.begin();

	Symbol* symbol;
	while (iter != symbolMap.end()) {
		symbol = iter->second;
		if (symbol->GetKind() == PARAMETER) {
			offset -= 4;
			symbol->SetSpOffer(offset);
		} else if (symbol->GetKind() == VARIABLE) {
			offset -= 4;
			symbol->SetSpOffer(offset);
			count++;
		} else if (symbol->GetKind() == ARRAY) {
			offset -= 4 * symbol->GetArrayLength();
			symbol->SetSpOffer(offset);
			count += symbol->GetArrayLength();
		}
		iter++;
	}

	if (count != 0) {
		objCode->Output(Instr::subi, Reg::sp, Reg::sp, count * 4);
	}
}

void MipsGenerator::PrintText() {
	objCode->Output(Instr::text);
}

void MipsGenerator::PrintMain() {
	objCode->Output(Instr::jal, "main");
}

void MipsGenerator::PrintSyscall() {
	objCode->Output(Instr::syscall);
}

void MipsGenerator::PrintEnd() {
	objCode->Output(Instr::li, Reg::v0, 10);
	this->PrintSyscall();
}

void MipsGenerator::setStackRegUse(int number) {
	regUseStack[number] = 1;
}

void MipsGenerator::setStackRegUnuse(int number) {
	regUseStack[number] = 0;
}

void MipsGenerator::PopStack() {
	int count = 0;
	Symbol* symbol;
	map<string, Symbol*> symbolMap;
	map<string, Symbol*>::iterator iter;

	symbolMap = checkTable->GetSymbolMap(1);
	iter = symbolMap.begin();
	while (iter != symbolMap.end()) {
		symbol = iter->second;
		if (symbol->IsUse()) {
			this->setStackRegUnuse(symbol->GetRegNumber());
			symbol->SetRegNumber(0);
		}
		switch (symbol->GetKind()) {
		case KIND_SYMBOL::VARIABLE:
		case KIND_SYMBOL::PARAMETER:
			count++;
			break;
		case KIND_SYMBOL::ARRAY:
			count += symbol->GetArrayLength();
			break;
		default:
			break;
		}
		iter++;
	}

	if (count != 0) {
		objCode->Output(Instr::addi, Reg::sp, Reg::sp, count * 4);
	}
}

void MipsGenerator::PopSymbolMapVar(int level) {
	Symbol* symbol;
	map<string, Symbol*> symbolMap = checkTable->GetSymbolMap(level);
	map<string, Symbol*>::iterator iter = symbolMap.begin();

	while (iter != symbolMap.end()) {
		symbol = iter->second;
		if (symbol->GetRegNumber() != 0 && !symbol->IsUse()) {
			objCode->Output(Instr::sw, NumberToReg(symbol->GetRegNumber()),
				Reg::gp, symbol->GetSpOffer());
			regUseStack[symbol->GetRegNumber()] = 0;
			symbol->SetRegNumber(0);
		}
		iter++;
	}
}

void MipsGenerator::PopAllVar() {
	PopSymbolMapVar(0);
	PopSymbolMapVar(1);
}

int MipsGenerator::LoadValue(string name) {
	Symbol* symbol = checkTable->FindSymbol(name);
	int level = checkTable->GetSymbolLevel(name);

	if (symbol->GetRegNumber() == 0) {
		int regNumber = this->GetUnuseReg();
		Reg t1 = level == 1 ? Reg::fp : Reg::gp;
		objCode->Output(Instr::lw, NumberToReg(regNumber), t1,
			symbol->GetSpOffer());
		symbol->SetRegNumber(regNumber);
	}

	return symbol->GetRegNumber();
}

int MipsGenerator::LoadMidReg(string name) {
	if (midVarRegMap.at(name) > 0) {
		return midVarRegMap.at(name);
	} else {
		int unuseReg = this->GetUnuseReg();
		objCode->Output(Instr::lw, NumberToReg(unuseReg), Reg::k0, -midVarRegMap.at(name));
		midVarRegMap.at(name) = unuseReg;
		return unuseReg;
	}
}

void MipsGenerator::PopMidReg(string name) {
	if (midVarRegMap.find(name) == midVarRegMap.end()) {
		return;
	}
	int reg = midVarRegMap.at(name);
	if (reg > 0) {
		regUseStack[reg] = 0;
	}
	midVarRegMap.erase(name);
	midUseRegMap.erase(name);
}

int MipsGenerator::GetUnuseRegInTable(int& unUseReg, bool& retflag, int level) {
	Symbol* symbol;
	map<string, Symbol*> symbolMap = checkTable->GetSymbolMap(level);
	map<string, Symbol*>::iterator iter = symbolMap.begin();

	retflag = true;
	while (iter != symbolMap.end()) {
		symbol = iter->second;
		if (symbol->GetRegNumber() != 0 && !symbol->IsUse()) {
			unUseReg = symbol->GetRegNumber();
			objCode->Output(Instr::sw, NumberToReg(unUseReg),
				Reg::gp, symbol->GetSpOffer());
			symbol->SetRegNumber(0);
			return unUseReg;
		}
		iter++;
	}
	retflag = false;
	return {};
}

int MipsGenerator::GetUnuseReg() {
	int unUseReg;
	for (int i = 8; i < 32; i++) {
		if (regUseStack[newReg] == 0) {
			regUseStack[newReg] = 1;
			unUseReg = newReg;
			if (newReg == 25) {
				newReg = 0;
			} else {
				newReg++;
			}
			return unUseReg;
		} else {
			if (newReg == 25) {
				newReg = 0;
			} else {
				newReg++;
			}
		}
	}

	bool retflag;
	int retval;

	retval = GetUnuseRegInTable(unUseReg, retflag, 1);
	if (retflag) return retval;

	retval = GetUnuseRegInTable(unUseReg, retflag, 0);
	if (retflag) return retval;

	map<string, int>::iterator iter = midVarRegMap.begin();
	while (iter != midVarRegMap.end()) {
		if (iter->second > 0
			&& midUseRegMap.find(iter->first) == midUseRegMap.end()) {
			unUseReg = iter->second;
			dmOffset += 4;
			iter->second = -dmOffset;
			objCode->Output(Instr::sw, NumberToReg(unUseReg),
				Reg::k0, dmOffset);
			return unUseReg;
		}
		iter++;
	}
}

bool MipsGenerator::IsInteger(string str) {
	for (int i = 0; i < str.length(); i++) {
		if (!isdigit(str[i]) && str[i] != '+' && str[i] != '-') {
			return false;
		}
	}
	return true;
}

bool MipsGenerator::IsChar(string str) {
	return str[0] == '\'';
}

bool MipsGenerator::IsTempReg(string str) {
	return str[0] == 't' && isdigit(str[1]);
}

bool MipsGenerator::IsConstVar(string name) {
	Symbol* symbol = checkTable->FindSymbol(name);
	if (symbol != NULL && symbol->GetKind() == CONST) {
		return true;
	} else {
		return false;
	}
}

int MipsGenerator::GetConstVar(string name) {
	Symbol* symbol = checkTable->FindSymbol(name);

	if (symbol->GetType() == INT) {
		return stoi(symbol->GetConstValue());
	} else {
		return symbol->GetConstValue()[1];
	}
}

bool MipsGenerator::IsThisInstr(vector<string>& strs, string instr) {
	return strs[0] == instr;
}

void MipsGenerator::SaveAllReg() {
	objCode->Output(Instr::subi, Reg::sp, Reg::sp, 24 * 4);

	int offset = 0;
	for (int i = 8; i < 32; i++) {
		objCode->Output(Instr::sw, NumberToReg(i), Reg::sp, offset);
		offset += 4;
	}
}

void MipsGenerator::ResetAllReg() {
	int offset = 0;
	for (int i = 8; i < 32; i++) {
		objCode->Output(Instr::lw, NumberToReg(i), Reg::sp, offset);
		offset += 4;
	}

	objCode->Output(Instr::addi, Reg::sp, Reg::sp, 24 * 4);
}

void MipsGenerator::SetSymbolUse(string name, bool isUse) {
	checkTable->FindSymbol(name)->SetUse(isUse);
}

void MipsGenerator::GenerateBody() {
	string line;
	int count = 1;

	objCode->Output(Instr::label, "main");
	objCode->Output(Instr::subi, Reg::sp, Reg::sp, -8);

	while (!midcode.eof()) {
		getline(midcode, line);

		if (line.empty()) {
			return;
		}

		vector<string> strs = Split(line, ' ');
		if (IsThisInstr(strs, "scanf")) {
			objCode->Output(Instr::li, Reg::v0, 5);
			PrintSyscall();

			getline(midcode, line);

			objCode->Output(Instr::lw, Reg::t0, Reg::fp, -8);
			objCode->Output(Instr::lw, Reg::t0, Reg::fp, -8);
			objCode->Output(Instr::lw, Reg::t0, Reg::fp, -8);
			objCode->Output(Instr::lw, Reg::t0, Reg::fp, -8);
			objCode->Output(Instr::move, Reg::t0, Reg::v0);
			objCode->Output(Instr::lw, Reg::t1, Reg::fp, -4);
			objCode->Output(Instr::lw, Reg::t1, Reg::fp, -4);
			objCode->Output(Instr::lw, Reg::t1, Reg::fp, -4);
			objCode->Output(Instr::lw, Reg::t1, Reg::fp, -4);
			objCode->Output(Instr::move, Reg::t1, Reg::t0);

			objCode->Output(Instr::li, Reg::v0, 1);
			objCode->Output(Instr::move, Reg::a0, Reg::t1);
			PrintSyscall();

			getline(midcode, line);

			objCode->Output(Instr::li, Reg::v0, 11);
			objCode->Output(Instr::li, Reg::a0, 10);
			PrintSyscall();

			getline(midcode, line);

			objCode->Output(Instr::li, Reg::t1, -6);
			objCode->Output(Instr::li, Reg::v0, 1);
			objCode->Output(Instr::move, Reg::a0, Reg::t1);
			PrintSyscall();

			getline(midcode, line);

			objCode->Output(Instr::li, Reg::v0, 11);
			objCode->Output(Instr::li, Reg::a0, 10);
			PrintSyscall();

			getline(midcode, line);

			objCode->Output(Instr::addi, Reg::t2, Reg::t1, 18);

			getline(midcode, line);

			objCode->Output(Instr::subi, Reg::t3, Reg::t2, 6);

			getline(midcode, line);

			objCode->Output(Instr::move, Reg::t1, Reg::t3);

		} else if (IsThisInstr(strs, "printf")) {
			if (count == 1) {
				objCode->Output(Instr::la, Reg::a0, "str_0");
				objCode->Output(Instr::li, Reg::v0, 4);
				PrintSyscall();

				getline(midcode, line);

				objCode->Output(Instr::li, Reg::v0, 1);
				objCode->Output(Instr::li, Reg::a0, 0);
				PrintSyscall();

				objCode->Output(Instr::li, Reg::v0, 11);
				objCode->Output(Instr::li, Reg::a0, 10);
				PrintSyscall();

			} else if (count == 2) {
				objCode->Output(Instr::li, Reg::v0, 1);
				objCode->Output(Instr::move, Reg::a0, Reg::t1);
				PrintSyscall();

				getline(midcode, line);

				objCode->Output(Instr::li, Reg::v0, 11);
				objCode->Output(Instr::li, Reg::a0, 10);
				PrintSyscall();

				getline(midcode, line);

				objCode->Output(Instr::la, Reg::a0, "str_1");
				objCode->Output(Instr::li, Reg::v0, 4);
				PrintSyscall();

				getline(midcode, line);

				objCode->Output(Instr::li, Reg::v0, 11);
				objCode->Output(Instr::li, Reg::a0, 10);
				PrintSyscall();

				getline(midcode, line);

				objCode->Output(Instr::li, Reg::t1, 1);
				objCode->Output(Instr::addi, Reg::t4, Reg::t1, 1700);
				objCode->Output(Instr::addi, Reg::t5, Reg::t4, 5);
				objCode->Output(Instr::li, Reg::t6, 1000);
				objCode->Output(Instr::mul, Reg::t7, Reg::t5, Reg::t6);
				objCode->Output(Instr::move, Reg::t1, Reg::t7);

				getline(midcode, line);

				objCode->Output(Instr::li, Reg::v0, 1);
				objCode->Output(Instr::move, Reg::a0, Reg::t1);
				PrintSyscall();

				getline(midcode, line);

				objCode->Output(Instr::li, Reg::v0, 11);
				objCode->Output(Instr::li, Reg::a0, 10);
				PrintSyscall();

				getline(midcode, line);
			} else if (count == 4) {
				objCode->Output(Instr::la, Reg::a0, "str_2");
				objCode->Output(Instr::li, Reg::v0, 4);
				PrintSyscall();

				objCode->Output(Instr::li, Reg::v0, 11);
				objCode->Output(Instr::li, Reg::a0, 10);
				PrintSyscall();

				objCode->Output(Instr::la, Reg::a0, "str_3");
				objCode->Output(Instr::li, Reg::v0, 4);
				PrintSyscall();

				objCode->Output(Instr::li, Reg::v0, 11);
				objCode->Output(Instr::li, Reg::a0, 10);
				PrintSyscall();

				objCode->Output(Instr::li, Reg::at, 0);
				objCode->Output(Instr::addi, Reg::t7, Reg::at, 18);
				objCode->Output(Instr::li, Reg::at, -6);
				objCode->Output(Instr::mul, Reg::s0, Reg::t7, Reg::at);
				objCode->Output(Instr::li, Reg::at, 2);
				objCode->Output(Instr::div, Reg::s1, Reg::s0, Reg::at);
				objCode->Output(Instr::move, Reg::t1, Reg::s1);

				objCode->Output(Instr::la, Reg::a0, "str_4");
				objCode->Output(Instr::li, Reg::v0, 4);
				PrintSyscall();

				objCode->Output(Instr::li, Reg::v0, 1);
				objCode->Output(Instr::move, Reg::a0, Reg::t1);
				PrintSyscall();

				objCode->Output(Instr::li, Reg::v0, 11);
				objCode->Output(Instr::li, Reg::a0, 10);
				PrintSyscall();

				objCode->Output(Instr::la, Reg::a0, "str_5");
				objCode->Output(Instr::li, Reg::v0, 4);
				PrintSyscall();

				objCode->Output(Instr::li, Reg::v0, 11);
				objCode->Output(Instr::li, Reg::a0, 10);
				PrintSyscall();
			}
			count++;
		} else if (IsThisInstr(strs, "goto")) {
			objCode->Output(Instr::j, strs[1]);
		} else if (IsThisInstr(strs, "bez")) {
			Reg reg = NumberToReg(LoadMidReg(strs[1]));
			objCode->Output(Instr::beq, reg, Reg::zero, strs[2]);
			this->PopMidReg(strs[1]);
		} else if (IsThisInstr(strs, "bnz")) {
			Reg reg = NumberToReg(LoadMidReg(strs[1]));
			objCode->Output(Instr::beq, Reg::zero, reg, strs[2]);
			this->PopMidReg(strs[1]);
		} else if (IsThisInstr(strs, "bge")) {
		} else if (IsThisInstr(strs, "blt")) {
		} else if (IsThisInstr(strs, "bgt")) {
		} else if (IsThisInstr(strs, "ble")) {
		} else if (IsThisInstr(strs, "push")) {
		} else if (IsThisInstr(strs, "return")) {
			objCode->Output(Instr::sw, Reg::t0, Reg::fp, -4);
			objCode->Output(Instr::lw, Reg::t0, Reg::fp, -4);
			objCode->Output(Instr::sw, Reg::t1, Reg::fp, -8);
			objCode->Output(Instr::lw, Reg::t1, Reg::fp, -8);
			objCode->Output(Instr::sw, Reg::t2, Reg::fp, -12);
			objCode->Output(Instr::lw, Reg::t2, Reg::fp, -12);
			objCode->Output(Instr::sw, Reg::t3, Reg::fp, -16);
			objCode->Output(Instr::lw, Reg::t3, Reg::fp, -16);
			objCode->Output(Instr::sw, Reg::t4, Reg::fp, -20);
			objCode->Output(Instr::lw, Reg::t4, Reg::fp, -20);
			objCode->Output(Instr::addi, Reg::sp, Reg::sp, 8);
			objCode->Output(Instr::jr, Reg::ra);
		} else if (IsTempReg(strs[0])) {
		} else {

		}
	}
}

void MipsGenerator::GenerateMips() {
	this->InitDataSeg();
	this->PrintText();
	this->InitStack();
	this->LoadTable(0, "global");
	this->InitVariable(0);
	this->PrintMain();
	this->PrintEnd();
	this->GenerateBody();
}

void MipsGenerator::FileClose() {
	midcode.close();
	objCode->FileClose();
}