﻿ #include "objcode.h"

ObjCode::ObjCode(string mipsFile) {
	this->mips.open(mipsFile);
}

void ObjCode::Output(Instr instr) {
	switch (instr) {
	case(Instr::syscall):
		mips << "syscall" << endl;
		break;
	case(Instr::data):
		mips << endl << ".data" << endl;
		break;
	case(Instr::text):
		mips << ".text" << endl << endl;
		break;
	default:
		assert(0);
	}
}

void ObjCode::Output(Instr instr, Reg t0) {
	switch (instr) {
	case(Instr::jr):
		mips << "jr " << RegToString(t0) << endl;
		break;
	default:
		assert(0);
	}
}

void ObjCode::Output(Instr instr, int value) {
	switch (instr) {
	case(Instr::data_align):
		mips << '\t' << ".align " << value << endl;
		break;
	default:
		assert(0);
	}
}

void ObjCode::Output(Instr instr, string label) {
	switch (instr) {
	case(Instr::jal):
		mips << "jal " << label << endl;
		break;
	case(Instr::j):
		mips << "j " << label << endl;
		break;
	case(Instr::label):
		mips << endl << label << ":" << endl;
		break;
	case(Instr::data_string):
		mips << '\t' << label << endl;
		break;
	default:
		assert(0);
	}
}

void ObjCode::Output(Instr instr, Reg t0, Reg t1) {
	switch (instr) {
	case(Instr::move):
		mips << "move " << RegToString(t0) << " " << RegToString(t1) << endl;
		break;
	default:
		assert(0);
	}
}

void ObjCode::Output(Instr instr, Reg t0, int value) {
	switch (instr) {
	case(Instr::li):
		mips << "li " << RegToString(t0) << " " << value << endl;
		break;
	default:
		assert(0);
	}
}

void ObjCode::Output(Instr instr, Reg t0, string label) {
	switch (instr) {
	case(Instr::la):
		mips << "la " << RegToString(t0) << " " << label << endl;
		break;
	default:
		assert(0);
	}
}

void ObjCode::Output(Instr instr, Reg t0, Reg t1, Reg t2) {
	switch (instr) {
	case(Instr::add):
		mips << "add " << RegToString(t0) << " " << RegToString(t1) << " " << RegToString(t2) << endl;
		break;
	case(Instr::sub):
		mips << "sub " << RegToString(t0) << " " << RegToString(t1) << " " << RegToString(t2) << endl;
		break;
	case(Instr::mul):
		mips << "mul " << RegToString(t0) << " " << RegToString(t1) << " " << RegToString(t2) << endl;
		break;
	case(Instr::div):
		mips << "div " << RegToString(t0) << " " << RegToString(t1) << " " << RegToString(t2) << endl;
		break;
	default:
		assert(0);
	}
}

void ObjCode::Output(Instr instr, string label, int value) {
	switch (instr) {
	case(Instr::data_identifier):
		mips << '\t' << label << ": .space " << value << endl;
		break;
	default:
		assert(0);
	}
}

void ObjCode::Output(Instr instr, Reg t0, Reg t1, int value) {
	switch (instr) {
	case(Instr::addi):
		mips << "addi " << RegToString(t0) << " " << RegToString(t1) << " " << value << endl;
		break;
	case(Instr::subi):
		mips << "subi " << RegToString(t0) << " " << RegToString(t1) << " " << value << endl;
		break;
	case(Instr::sll):
		mips << "sll " << RegToString(t0) << " " << RegToString(t1) << " " << value << endl;
		break;
	case(Instr::lw):
		mips << "lw " << RegToString(t0) << " " << value << "(" << RegToString(t1) << ")" << endl;
		break;
	case(Instr::sw):
		mips << "sw " << RegToString(t0) << " " << value << "(" << RegToString(t1) << ")" << endl;
		break;
	default:
		assert(0);
	}
}

void ObjCode::Output(Instr instr, Reg t0, Reg t1, string label) {
	switch (instr) {
	case(Instr::lw):
		mips << "lw " << RegToString(t0) << " " << label << "(" << RegToString(t1) << ")" << endl;
		break;
	case(Instr::sw):
		mips << "sw " << RegToString(t0) << " " << label << "(" << RegToString(t1) << ")" << endl;
		break;
	case(Instr::bgt):
		mips << "bgt " << RegToString(t0) << " " << RegToString(t1) << " " << label << endl;
		break;
	case(Instr::bge):
		mips << "bge " << RegToString(t0) << " " << RegToString(t1) << " " << label << endl;
		break;
	case(Instr::blt):
		mips << "blt " << RegToString(t0) << " " << RegToString(t1) << " " << label << endl;
		break;
	case(Instr::ble):
		mips << "ble " << RegToString(t0) << " " << RegToString(t1) << " " << label << endl;
		break;
	case(Instr::beq):
		mips << "beq " << RegToString(t0) << " " << RegToString(t1) << " " << label << endl;
		break;
	case(Instr::bne):
		mips << "bne " << RegToString(t0) << " " << RegToString(t1) << " " << label << endl;
		break;
	default:
		assert(0);
	}
}

void ObjCode::FileClose() {
	this->mips.close();
}