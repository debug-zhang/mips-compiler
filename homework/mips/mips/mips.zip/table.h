﻿#pragma once

#include <string>
#include <map>
#include <vector>
#include "symbol.h"

using namespace std;

class StringTable {
private:
	map<int, string> stringMap;
	int stringNumber;
public:
	StringTable();
	int AddString(string str);
	int GetStringCount();
	string GetString(int stringNumber);
};

class SymbolTable {
private:
	map<string, Symbol*> symbolMap;
public:
	SymbolTable();
	Symbol* AddSymbol(string name, KIND_SYMBOL kind, TYPE_SYMBOL type);
	Symbol* FindSymbol(string name);
	map<string, Symbol*> GetSymbolMap();
};

class CheckTable {
private:
	vector<SymbolTable*> symbolMapVector;
public:
	CheckTable();
	Symbol* AddSymbol(string name, KIND_SYMBOL kind, TYPE_SYMBOL type, int level);
	Symbol* FindSymbol(string name);
	Symbol* FindSymbol(string name, int level);
	int GetSymbolLevel(string name);
	void ClearLevel(int level);
	void SetTable(int level, SymbolTable* symbolTable);
	SymbolTable* GetSymbolTable(int level);
	map<string, Symbol*> GetSymbolMap(int level);
};