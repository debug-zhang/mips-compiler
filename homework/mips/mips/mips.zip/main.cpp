﻿#include <iostream>
#include "lexical_analyser.h"
#include "parse_analyser.h"
#include "mips_generator.h"
#include "error_handing.h"

using namespace std;

int main() {
	string testfile = "testfile.txt";
	string midcode = "midcode.txt";
	string mips = "mips.txt";
	string error = "error.txt";

	ErrorHanding* errorHanding = new ErrorHanding(error);

	LexicalAnalyser* lexicalAnalyser = new LexicalAnalyser(testfile, errorHanding);

	ParseAnalyser* parseAnalyser = new ParseAnalyser(midcode, lexicalAnalyser->Analyze(), errorHanding);
	lexicalAnalyser->FileClose();
	parseAnalyser->AnalyzeParse();
	parseAnalyser->FileClose();

	MipsGenerator* mipsGenerator = new MipsGenerator(midcode, mips, 
		parseAnalyser->GetstringTable(), parseAnalyser->GetSymbolTableMap());
	mipsGenerator->GenerateMips();
	mipsGenerator->FileClose();

	errorHanding->PrintError();
	errorHanding->FileClose();

	return 0;
}